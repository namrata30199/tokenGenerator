package com.generatecrud.tokens.Controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.generatecrud.tokens.Constants.TurnConstants;
import com.generatecrud.tokens.Entity.Turn;
import com.generatecrud.tokens.Repository.TurnRepository;

import net.minidev.json.parser.JSONParser;

@RestController
@RequestMapping("/v1/turn")
public class TurnGeneratorController {

	@Autowired
	private TurnRepository turnRepository;

	@PostMapping("/create")
	public ResponseEntity<?> createTurnUser(@RequestBody Turn turn) {

		turn.setLastTurnTime(currentInstance());
		turnRepository.save(turn);
		return new ResponseEntity<>(TurnConstants.NEW_USER_CREATED, HttpStatus.CREATED);

	}

	@GetMapping("/find-turn")
	public ResponseEntity<?> getTurnInformation() {

		List<Turn> turnDataList = turnRepository.findAll();
		if (turnDataList.size() == 0)
			return new ResponseEntity<>(TurnConstants.NO_DATA, HttpStatus.NOT_FOUND);

		Turn currentTurnObject = turnDataList.stream().min(Comparator.comparing(Turn::getLastTurnTime)).get();

		// update current turn as it has performed its duty
		currentTurnObject.setLastTurnTime(currentInstance());
		currentTurnObject.setIsTurn(true);

		// set all other object turns as false
		for (Turn eachTurnObject : turnDataList) {
			if (!eachTurnObject.getId().equals(currentTurnObject.getId()))
				eachTurnObject.setIsTurn(false);
		}

		turnRepository.save(currentTurnObject);

		return new ResponseEntity<>(currentTurnObject, HttpStatus.OK);
	}

	public static LocalDateTime currentInstance() {
		return LocalDateTime.of(LocalDate.now(), LocalTime.now());
	}
	
	@GetMapping("/read-json-data")
	public ResponseEntity<?> retrieveDataFromJsonFile() throws FileNotFoundException, JSONException { 		
		File file = new File(this.getClass().getClassLoader().getResource("abc.json").getFile());
	
		@SuppressWarnings("resource")
		String myJson = new Scanner(file).useDelimiter("\\Z").next();
		
		JSONObject jsonData = new JSONObject(myJson);
		return new ResponseEntity<>(jsonData,HttpStatus.OK);
	}
	
	

}
