package com.generatecrud.tokens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokenatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TokenatorApplication.class, args);
	}
}
