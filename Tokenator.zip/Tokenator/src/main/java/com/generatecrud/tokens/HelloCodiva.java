package com.generatecrud.tokens;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.assertj.core.util.Arrays;

class HelloCodiva {
	  
	  public static void main(String[] args) {
	    
	  	final int[] a = {1,5,2,2,3,3};
	    
	    
	  }
	  
	  public static int getnhighest(final int[] a){
	    
	    Set<Integer> set = new HashSet<>();
	    for(int i : a)
	    	set.add(i);
		return 0;
	    
	    //Collections.sort(set);
	  }
	  
	}