package com.generatecrud.tokens.Entity;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
@Entity(name = "Turn_TBL")
public class Turn {

	@Id
	@Column(name = "id")
	@GeneratedValue
	private Long id;

	@Column(name = "name",unique=true)
	@NotNull(message = "Turn taker name should not be left blank")
	private String name;

	@Column(name = "updatedTurnTime")
	private LocalDateTime lastTurnTime;

	@Column(name = "isTurn",columnDefinition = "boolean default false", nullable = false)
	private Boolean isTurn = false;

	@Override
	public String toString() {
		return "Turn [id=" + id + ", name=" + name + ", lastTurnTime=" + lastTurnTime + ", isTurn=" + isTurn + "]";
	}

	public Turn(Long id, @NotNull(message = "Turn taker name should not be left blank") String name,
			LocalDateTime lastTurnTime, Boolean isTurn) {
		super();
		this.id = id;
		this.name = name;
		this.lastTurnTime = lastTurnTime;
		this.isTurn = isTurn;
	}

	
	
	public Turn(@NotNull(message = "Turn taker name should not be left blank") String name, LocalDateTime lastTurnTime,
			Boolean isTurn) {
		super();
		this.name = name;
		this.lastTurnTime = lastTurnTime;
		this.isTurn = isTurn;
	}

	public Turn() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getLastTurnTime() {
		return lastTurnTime;
	}

	public void setLastTurnTime(LocalDateTime lastTurnTime) {
		this.lastTurnTime = lastTurnTime;
	}

	public Boolean getIsTurn() {
		return isTurn;
	}

	public void setIsTurn(Boolean isTurn) {
		this.isTurn = isTurn;
	}

	
}
