package com.generatecrud.tokens;

import java.util.Stack;

public class test1 {
	
	
	public static void main(String[] args) {
		System.out.println(solution1(new int[] {1,1,1}
		));
	}
	 public int solution(int[] H) {
	        Stack<Integer> wallheight = new Stack<>();
	        int blockLength = H.length;
	        wallheight.push(H[0]);
	        int j = 0;
	        for (int i = 1 ; i < blockLength; i++) {
	            int maxHeight = wallheight.peek();
	            if (maxHeight < H[i]) {
	                wallheight.push(H[i]);
	            } else if (maxHeight > H[i]) {
	                wallheight.pop();
	                j++;
	                if (!wallheight.empty()) {
	                    maxHeight = wallheight.peek();

	                    while (!wallheight.empty() && maxHeight > H[i]) {
	                        j++;
	                        wallheight.pop();
	                        if (!wallheight.empty()) {
	                            maxHeight = wallheight.peek();
	                        }
	                    }
	                    if (maxHeight == H[i]) {
	                        wallheight.pop();
	                    }
	                }
	                wallheight.push(H[i]);
	            }
	        }
	        j += wallheight.size();
	        return j;
	    }
	 
	 

	    public static int solution1(int[] H) {
	        Stack<Integer> wall = new Stack<Integer>();
	        int j = 0;
	        int wallLength = H.length;
	        for(int k = 0; k < wallLength; k++){             
	              if(wall.size() == 0)
	              {
	                 j++;
	                 wall.push(H[k]);
	              }else{
	                 if(wall.peek() > H[k]){
	                    while(wall.size() > 0 && wall.peek() > H[k] ) {
	                    		wall.pop();
	                    }
	                    k--;
	                }else if(wall.peek() < H[k]){
	                    j++;
	                    wall.push(H[k]);
	                }
	            }
	        }
	        return j+1;
	    }
}
