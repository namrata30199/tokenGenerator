package com.generatecrud.tokens.Constants;

public class TurnConstants {

	public static final String NO_DATA = "no data available";
	public static final String NEW_USER_CREATED  = "New user created";
}
