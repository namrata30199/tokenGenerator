package com.generatecrud.tokens.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.generatecrud.tokens.Entity.Turn;

@Repository
public interface TurnRepository extends JpaRepository<Turn, Long> {

	


}
