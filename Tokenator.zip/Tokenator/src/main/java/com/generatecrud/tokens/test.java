package com.generatecrud.tokens;

import java.util.HashMap;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	HashMap<String, String> as = new HashMap<>();
	String a = new String();
	a = "aakash";
	as.put(a, "hi");
	a = new String("prakash");
	System.out.println(as.get("aakash"));}
		

	public static int retOccurenceOfOne(int n) {
		int count = 0;
		int i = 1;
		while (i <= n) {
			if (i % 10 == 1)
				count++;
			if (i != 0 && i / 10 == 1) {
				count++;
				i++;
			}
			else if (i / 10 == 0)
				i  +=  9;
			else
				i += 10;
		}
		return count;
	}
	
	long f(int n) // counts how many 1's for number n
	{
	    long out = 0;
	    for ( ; n != 0; n /= 10) {
	    	 out += (n % 10 == 1)?1:0;
	    }
	       
	    return out;
	}

	
	
	
	public static int treeArrangement(int[] arr) {
		int count = 0;
		for(int i = 0 ; i<arr.length ; i++) {
			if(isArranged(arr,i))
				count++;
		}
		return count;
	}
	
	public static boolean  isArranged(final int[] arr, int k) {	
		
	
		for(int i = k ; i< arr.length -1 ; i++) {
			arr[i]=arr[i+1] + (-arr[i]) + (arr[i+1] = arr[i]);
		}
		for(int i=0;i<arr.length-2;i++) {
			if(arr[i]>arr[i+1])
				return false;
		}
		return true;
		
	}
	
	public static int[] moveValueAtIndexToLast(int[] arrayToBeShifted, int index) {
		
		  int valueBeingMoved = arrayToBeShifted[index];
		  for (int i = index; i < arrayToBeShifted.length; i++) {
		    arrayToBeShifted[i] = arrayToBeShifted[i++];
		  }
		  arrayToBeShifted[arrayToBeShifted.length-1] = valueBeingMoved;
		  return arrayToBeShifted;
	}
	
	
	
	
	
	
	
	
}

