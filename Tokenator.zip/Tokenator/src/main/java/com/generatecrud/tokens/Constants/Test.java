package com.generatecrud.tokens.Constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(getMinimumTravelTime("4,5,2,3"));
	}

	/*
	 * public static List<String> findTopScorers(int totalPlayers,int totalMatches,
	 * List<String> scores, int n){ String[] pNameAndScores = scores.toArray(new
	 * String[scores.size()]); Map<String,Integer> matchesWonPerPlayer = new
	 * HashMap<>();
	 * 
	 * List<String> topScorerPlayers = new ArrayList<String>();
	 * 
	 * for(Entry<String, Integer> eachMatch:matchesWonPerPlayer.entrySet()) {
	 * if(eachMatch.getValue()>=n) topScorerPlayers.add(eachMatch.getKey()); }
	 * while(totalPlayers-->0) {
	 * 
	 * }
	 * 
	 * }
	 */

	public static int getMinimumTravelTime(String weightsOfPeople) {
		int sum = 0;
		String[] arrayofweights = weightsOfPeople.split(",");
		int[] array = Arrays.asList(arrayofweights).stream().mapToInt(Integer::parseInt).toArray();
		Arrays.sort(array);
		// if only 2 people go
		if (array.length == 2)
			return Math.max(array[0], array[1]);

		// if more than 2 people or 1 of them go
		for (int i = 0; i < array.length; i++) {
			sum += array[i];
		}

		// if someone has to return
		if (array.length > 3)
			return sum + array[0] * (array.length - 3);

		// valid for 1 element as well
		return sum;

	}

	public static List<String> findTopScorers(int totalNoPlayers, int totalMatches, List<String> scores, int n) {
		Map<String, List<Integer>> hashmap = new HashMap<>();
		int[] maxMatch = new int[totalMatches];

		for (int i = 0; i < totalNoPlayers; i++) {
			String str = scores.get(i);
			List<String> items = Arrays.asList(str.split("\\s*,\\s*"));
			String player = items.get(0);
			List<Integer> list = new ArrayList<>();
			for (int j = 1; j < items.size(); j++) {
				int num = Integer.parseInt(items.get(j));
				if (maxMatch[j - 1] < num) {
					maxMatch[j - 1] = num;
				}
				list.add(num);
			}

			hashmap.put(player, list);
		}

		List<String> playerList = new ArrayList<>();

		Iterator it = hashmap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();

			List<Integer> list = (List<Integer>) pair.getValue();
			int count = 0;
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i) == maxMatch[i]) {
					count++;

					if (count >= n) {
						playerList.add((String) pair.getKey());
						break;
					}
				}
			}
		}

		playerList.sort(String::compareToIgnoreCase);

		return playerList;
	}

}
